package test01;

import java.util.Scanner;

public class main {
	public static void main(String[] args) {
		LifeGame game = new LifeGame();
		Cell[][] cells = new Cell[8][8];//Ĭ�����̴�СΪ8
		game.run_game(cells);
		GUI myGUI = new GUI("������Ϸ");
	}
}


